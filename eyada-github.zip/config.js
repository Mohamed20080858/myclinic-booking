// Paste your Google Maps JavaScript API key here (see README.md, step 1).
// Restrict the key to your website's domain in Google Cloud Console.
window.EYADA_GMAPS_KEY = "YOUR_GOOGLE_MAPS_API_KEY";
