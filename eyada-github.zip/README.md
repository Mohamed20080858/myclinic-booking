# Eyada

Rent clinic rooms by the shift in Cairo. Installable web app (PWA), English and Arabic.

Hosted as a static site: no build step. On Vercel, import this repository with Framework Preset "Other" and leave the build settings empty.
